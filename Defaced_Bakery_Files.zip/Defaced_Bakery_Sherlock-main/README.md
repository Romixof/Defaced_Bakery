# Case: The Defaced Bakery
**Scenario:**  
Attackers hacked ByteBakery's WordPress site, defaced the homepage, and left a backdoor. Analyze the logs to answer:

## Questions:
1. Attacker's IP that logged in successfully?
2. Weak password used?
3. Webshell filename?
4. Database table dumped?
5. Command used to wipe logs?

## Files Provided:
- `/logs/apache_access.log` - Web server traffic
- `/logs/error.log` - System/application errors  
- `/logs/file_changes.txt` - File modifications
- `/database/wordpress_users.csv` - User credentials

**GOOD LUCK ! 😀**  
